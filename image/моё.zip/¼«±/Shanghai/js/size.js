const size = document.querySelector('.size');

size.addEventListener('mouseenter', function(){
    size.classList.add('hover');
});
size.addEventListener('mouseleave', function(){
    size.classList.remove('hover');
})

//==============================================================

const heading_block1 = document.querySelector('.heading_block1');

heading_block1.addEventListener('mouseenter', function(){
    heading_block1.classList.add('hover');
});
heading_block1.addEventListener('mouseleave', function(){
    heading_block1.classList.remove('hover');
})

//==============================================================

const heading_block2 = document.querySelector('.heading_block2');

heading_block2.addEventListener('mouseenter', function(){
    heading_block2.classList.add('hover');
});
heading_block2.addEventListener('mouseleave', function(){
    heading_block2.classList.remove('hover');
})

//==============================================================

const heading_block3 = document.querySelector('.heading_block3');

heading_block3.addEventListener('mouseenter', function(){
    heading_block3.classList.add('hover');
});
heading_block3.addEventListener('mouseleave', function(){
    heading_block3.classList.remove('hover');
})